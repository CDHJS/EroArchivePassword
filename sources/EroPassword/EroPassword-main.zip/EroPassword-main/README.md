# EroPassword
一些常用的解压密码（包括但不限于本子、里番、galgame）

欢迎大佬补充
# 附赠密码测试工具

原帖下载地址:

链接:https://pan.baidu.com/s/1mB7rzJq_1MkpnuOTNOWnbQ

提取码:byr5

作者：世界丿凌晨

来源 https://www.bilibili.com/read/cv6101558
