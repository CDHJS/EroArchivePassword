echo $1 >> old-driver-passwords
echo Added password \'$1\'
./sort-password.sh
