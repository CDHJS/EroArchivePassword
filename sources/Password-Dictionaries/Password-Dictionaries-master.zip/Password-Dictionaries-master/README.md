# Password-Dictionaries

### Domain-Name

部分压缩资料喜欢用发布资料的网站域名作为解压缩密码，这是我遇到最多的情况。

### Number

纯数字解压缩密码

### String

数字、字母、符号及中文混合的解压缩密码


欢迎添加暂时没有的密码~